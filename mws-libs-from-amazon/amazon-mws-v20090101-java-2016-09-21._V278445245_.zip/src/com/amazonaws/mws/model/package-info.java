@javax.xml.bind.annotation.XmlSchema(namespace = "http://mws.amazonaws.com/doc/2009-01-01/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.amazonaws.mws.model;
